const express = require('express');
const app = express();
const port = 3000;

import axios from 'axios'
import router  from './index.js'

app.use(router,VueAxios,axios).mount('#app')


app.use(express.json());

let saldo = 500000;

app.get('/saldo', (req, res) => {
  res.json({ saldo });
});

app.post('/pesan', (req, res) => {
  const { jumlah, harga } = req.body;

  const totalHarga = jumlah * harga;

  if (totalHarga > saldo) {
    res.status(400).json({ error: 'Saldo tidak mencukupi' });
  } else {
    saldo -= totalHarga;
    res.json({ saldo, message: 'Pemesanan berhasil' });
  }
});

app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});