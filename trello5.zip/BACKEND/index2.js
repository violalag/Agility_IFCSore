import { createWebHistory , createRouter} from 'vue-router'
import Menu from './menu.vue'
import Edit from './edit.vue'
import Create from './add.vue'


const routes = [
    {
        name : 'Create',
        path : '/menu/add',
        component : Create
    },
    {
        name : 'Edit',
        path : '/menu/products/:id',
        component : Edit
    },
    {
        name : 'Menu',
        path : '/menu/products',
        component : Menu
    }
]

const router = createRouter({history: createWebHistory(),routes})

export default router